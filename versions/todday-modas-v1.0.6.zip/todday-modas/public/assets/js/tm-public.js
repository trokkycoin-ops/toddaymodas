/* Público — Todday Modas v1.0.5. Leve, sem dependências. */
(function () {
	'use strict';

	var prm = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

	/* ============ PWA: registra service worker ============ */
	if ('serviceWorker' in navigator) {
		window.addEventListener('load', function () {
			navigator.serviceWorker.register('/tm-sw.js', { scope: '/' }).catch(function () { /* silencioso */ });
		});
	}

	/* ============ Header: efeito "vidro" ao rolar ============ */
	var isMobile = window.matchMedia && window.matchMedia('(max-width: 768px)');
	var lastY = 0;
	function onScroll() {
		var y = window.scrollY || 0;
		document.body.classList.toggle('tm-scrolled', y > 12);
		// esconde/mostra header ao rolar pra cima/baixo (comportamento app-like SÓ no mobile)
		var header = document.querySelector('.site-header, header.ast-primary-header-bar, .ast-desktop-header');
		if (header && isMobile.matches) {
			if (y > 180 && y > lastY + 6) { document.body.classList.add('tm-header-hidden'); }
			else if (y < lastY - 6) { document.body.classList.remove('tm-header-hidden'); }
		} else {
			document.body.classList.remove('tm-header-hidden');
		}
		lastY = y;
	}
	window.addEventListener('scroll', onScroll, { passive: true });
	if (isMobile.addEventListener) { isMobile.addEventListener('change', onScroll); }

	document.addEventListener('DOMContentLoaded', function () {

		/* ============ Animações de entrada (IntersectionObserver, stagger) ============ */
		var alvos = document.querySelectorAll(
			'.tm-hero, .tm-secao, .tm-fullbleed, .tm-cat-card, .tm-cupom, ' +
			'.woocommerce ul.products li.product, .tm-card-produto-destaque, .tm-banner-cta, ' +
			'.tm-footer, .tm-contato-canal, .tm-faq details, .tm-newsletter, .tm-doc'
		);
		if (prm || !('IntersectionObserver' in window)) {
			alvos.forEach(function (el) { el.classList.add('tm-in'); });
		} else {
			alvos.forEach(function (el, i) {
				el.classList.add('tm-pre');
				el.style.setProperty('--tm-delay', ((i % 6) * 70) + 'ms');
			});
			var io = new IntersectionObserver(function (entries) {
				entries.forEach(function (en) {
					if (en.isIntersecting) {
						en.target.classList.add('tm-in');
						io.unobserve(en.target);
					}
				});
			}, { threshold: 0.08, rootMargin: '0px 0px -6% 0px' });
			alvos.forEach(function (el) { io.observe(el); });
		}

		/* ============ Overlay de busca (app bar) ============ */
		var overlay = document.getElementById('tm-busca-overlay');
		var btnOpen = document.getElementById('tm-busca-open');
		var btnClose = document.getElementById('tm-busca-close');
		var campo = document.getElementById('tm-busca-campo');

		function abrirBusca() {
			if (!overlay) { return; }
			overlay.hidden = false;
			document.body.classList.add('tm-busca-aberta');
			requestAnimationFrame(function () {
				overlay.classList.add('is-open');
				if (campo) { campo.focus(); }
			});
		}
		function fecharBusca() {
			if (!overlay) { return; }
			overlay.classList.remove('is-open');
			document.body.classList.remove('tm-busca-aberta');
			setTimeout(function () { overlay.hidden = true; }, 260);
			if (btnOpen) { btnOpen.focus(); }
		}
		if (btnOpen) { btnOpen.addEventListener('click', abrirBusca); }
		if (btnClose) { btnClose.addEventListener('click', fecharBusca); }
		if (overlay) {
			overlay.addEventListener('click', function (e) { if (e.target === overlay) { fecharBusca(); } });
		}
		document.addEventListener('keydown', function (e) {
			if (e.key === 'Escape' && overlay && !overlay.hidden) { fecharBusca(); }
		});

		/* ============ Header desktop: busca + sacola + conta (injeção no menu Astra) ============ */
		var dados = window.TMDados || null;
		var desktopNav = null;
		var itensInjetados = false;

		function atualizarBadge(qtd) {
			var badges = document.querySelectorAll('.tm-hdr-badge');
			badges.forEach(function (b) {
				b.textContent = String(Math.min(99, qtd));
				b.classList.toggle('is-ativo', qtd > 0);
				b.setAttribute('aria-label', qtd + ' ' + (dados ? dados.rotuloCarrinho : ''));
			});
		}

		function injetarHeaderDesktop() {
			if (itensInjetados || !dados) { return; }
			if (!window.matchMedia || !window.matchMedia('(min-width: 769px)').matches) { return; }
			desktopNav = document.querySelector('#ast-desktop-header .main-header-menu, .ast-desktop-header ul.main-header-menu');
			if (!desktopNav) {
				desktopNav = document.querySelector('.ast-builder-menu-1 ul.main-header-menu');
			}
			if (!desktopNav) { return; }

			var liBusca = document.createElement('li');
			liBusca.className = 'menu-item tm-hdr-item';
			var btnBusca = document.createElement('button');
			btnBusca.type = 'button';
			btnBusca.className = 'tm-hdr-btn';
			btnBusca.setAttribute('aria-label', 'Buscar');
			btnBusca.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="10.5" cy="10.5" r="6.5"/><path d="m15.2 15.2 5 5"/></svg>';
			btnBusca.addEventListener('click', abrirBusca);
			liBusca.appendChild(btnBusca);

			var liSacola = document.createElement('li');
			liSacola.className = 'menu-item tm-hdr-item';
			var linkSacola = document.createElement('a');
			linkSacola.className = 'tm-hdr-link';
			linkSacola.href = dados.carrinhoUrl;
			linkSacola.setAttribute('aria-label', dados.rotuloCarrinho);
			linkSacola.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M6 8h12l-1 12H7z"/><path d="M9 8V6a3 3 0 0 1 6 0v2"/></svg>';
			var badge = document.createElement('em');
			badge.className = 'tm-hdr-badge';
			badge.setAttribute('aria-hidden', 'true');
			linkSacola.appendChild(badge);
			liSacola.appendChild(linkSacola);

			var liConta = document.createElement('li');
			liConta.className = 'menu-item tm-hdr-item';
			var linkConta = document.createElement('a');
			linkConta.className = 'tm-hdr-link';
			linkConta.href = dados.contaUrl;
			linkConta.setAttribute('aria-label', dados.rotuloConta);
			linkConta.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="8.5" r="4"/><path d="M4.5 21c1.5-4 5-5.5 7.5-5.5s6 1.5 7.5 5.5"/></svg>';
			liConta.appendChild(linkConta);

			desktopNav.appendChild(liBusca);
			desktopNav.appendChild(liSacola);
			desktopNav.appendChild(liConta);
			itensInjetados = true;
			atualizarBadge(dados.carrinhoQtd || 0);
		}

		// Re-tenta ao mudar o tamanho da janela (entra na faixa desktop depois).
		if (window.matchMedia) {
			var mqDesktop = window.matchMedia('(min-width: 769px)');
			if (mqDesktop.addEventListener) {
				mqDesktop.addEventListener('change', function (m) { if (m.matches) { injetarHeaderDesktop(); } });
			} else if (mqDesktop.addListener) {
				mqDesktop.addListener(function (m) { if (m.matches) { injetarHeaderDesktop(); } });
			}
		}
		injetarHeaderDesktop();

		// Atualiza os badges (header desktop + app bar) quando um item entra na sacola via AJAX.
		function aoAdicionarCarrinho(fragments) {
			var novo = null;
			if (fragments && fragments['div.widget_shopping_cart_content']) {
				// conta as linhas do mini-cart no fragment (mais confiável que incrementar)
				var holder = document.createElement('div');
				holder.innerHTML = fragments['div.widget_shopping_cart_content'];
				var total = 0;
				holder.querySelectorAll('li.cart_item, li.woocommerce-mini-cart-item').forEach(function (li) {
					var q = li.querySelector('.quantity, .product-quantity');
					var m = q ? q.textContent.match(/(\d+)/) : null;
					total += m ? parseInt(m[1], 10) : 1;
				});
				if (total > 0) { novo = total; }
			}
			if (novo === null) {
				novo = (dados ? dados.carrinhoQtd : 0) + 1;
			}
			if (dados) { dados.carrinhoQtd = novo; }
			atualizarBadge(novo);
			// badge da app bar mobile (cria se ainda não existir no link da sacola)
			document.querySelectorAll('.tm-appbar a[href*="carrinho"], .tm-appbar-item[href*="carrinho"]').forEach(function (link) {
				var badge = link.querySelector('.tm-appbar-badge');
				if (!badge && novo > 0) {
					badge = document.createElement('em');
					badge.className = 'tm-appbar-badge';
					badge.setAttribute('aria-label', novo + ' itens na sacola');
					link.appendChild(badge);
				}
				if (badge) {
					badge.textContent = String(Math.min(99, novo));
					if (novo > 0) { badge.classList.add('is-ativo'); }
				}
			});
		}
		if (dados && window.jQuery) {
			jQuery(document.body).on('added_to_cart', function (e, fragments) { aoAdicionarCarrinho(fragments); });
		} else if (dados) {
			document.body.addEventListener('added_to_cart', function (e, fragments) { aoAdicionarCarrinho(fragments); });
		}

		/* ============ Slider de banners ([tm_banners]) ============ */
		document.querySelectorAll('.tm-banners').forEach(function (secao) {
			var track = secao.querySelector('.tm-banners-track');
			var slides = secao.querySelectorAll('.tm-banner-slide');
			var prev = secao.querySelector('.tm-banners-prev');
			var next = secao.querySelector('.tm-banners-next');
			var dots = secao.querySelectorAll('.tm-banners-dot');
			var atual = 0;
			var total = slides.length;
			var timer = null;
			var autoplay = parseInt(secao.getAttribute('data-autoplay') || '0', 10) * 1000;

			if (!track || total <= 1) { return; }

			function irPara(i) {
				atual = (i + total) % total;
				track.style.transform = 'translateX(-' + (atual * 100) + '%)';
				dots.forEach(function (d, j) {
					var ativo = j === atual;
					d.classList.toggle('is-active', ativo);
					d.setAttribute('aria-selected', ativo ? 'true' : 'false');
				});
			}
			function play() {
				if (autoplay && prm === false) { timer = setInterval(function () { irPara(atual + 1); }, autoplay); }
			}
			function pause() { if (timer) { clearInterval(timer); timer = null; } }

			if (prev) { prev.addEventListener('click', function () { irPara(atual - 1); }); }
			if (next) { next.addEventListener('click', function () { irPara(atual + 1); }); }
			dots.forEach(function (d) {
				d.addEventListener('click', function () { irPara(parseInt(d.getAttribute('data-slide') || '0', 10)); });
			});

			secao.addEventListener('mouseenter', pause);
			secao.addEventListener('mouseleave', play);
			document.addEventListener('visibilitychange', function () { document.hidden ? pause() : play(); });

			// Swipe básico (touch).
			var x0 = null;
			secao.addEventListener('touchstart', function (e) {
				x0 = e.changedTouches[0].clientX;
				pause();
			}, { passive: true });
			secao.addEventListener('touchend', function (e) {
				if (x0 === null) { return; }
				var dx = e.changedTouches[0].clientX - x0;
				if (Math.abs(dx) > 40) { irPara(atual + (dx < 0 ? 1 : -1)); }
				x0 = null;
				play();
			}, { passive: true });

			play();
		});

		/* ============ Lazy load defensivo ============ */
		var imgs = document.querySelectorAll('.woocommerce img:not([loading])');
		imgs.forEach(function (img) {
			img.setAttribute('loading', 'lazy');
			img.setAttribute('decoding', 'async');
		});

		/* ============ Botões "copiar cupom" ============ */
		document.querySelectorAll('.tm-cupom-copiar').forEach(function (btn) {
			btn.addEventListener('click', function () {
				var codigo = btn.getAttribute('data-codigo') || '';
				var label = btn.querySelector('.tm-cupom-copiar-label');
				var original = label ? label.textContent : '';

				function sucesso() {
					btn.classList.add('copiado');
					if (label) { label.textContent = 'Copiado!'; }
					setTimeout(function () {
						btn.classList.remove('copiado');
						if (label) { label.textContent = original; }
					}, 2000);
				}

				if (navigator.clipboard && navigator.clipboard.writeText) {
					navigator.clipboard.writeText(codigo).then(sucesso).catch(function () {
						fallback(codigo, sucesso);
					});
				} else {
					fallback(codigo, sucesso);
				}
			});
		});

		function fallback(texto, cb) {
			var ta = document.createElement('textarea');
			ta.value = texto;
			ta.style.position = 'fixed';
			ta.style.opacity = '0';
			document.body.appendChild(ta);
			ta.select();
			try {
				document.execCommand('copy');
				cb();
			} catch (e) { /* silencioso */ }
			document.body.removeChild(ta);
		}
	});
})();
