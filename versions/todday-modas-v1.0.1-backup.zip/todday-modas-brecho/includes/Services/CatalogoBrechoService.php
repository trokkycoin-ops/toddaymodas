<?php
namespace ToddayModasBrecho\Services;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Lê o catálogo a partir das tabelas relacionais do modelo Todday Brechó
 * (categories, products, product_variations, product_colors, product_measurements).
 * Usado como fonte primária quando as tabelas existem e têm produtos ativos;
 * o CatalogController mantém o fallback para WooCommerce/comportamento atual.
 */
class CatalogoBrechoService {

    private static function table(string $name): string {
        global $wpdb;
        $candidates = [$wpdb->prefix . $name, $name];
        foreach ($candidates as $cand) {
            $found = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $cand));
            if ($found) {
                return $cand;
            }
        }
        return $wpdb->prefix . $name;
    }

    public static function has_custom_catalog(): bool {
        global $wpdb;
        $products = self::table('products');
        $count = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$products}");
        return $count > 0;
    }

    /**
     * Resolve o ID do produto WooCommerce de mesmo slug (mantém carrinho/checkout).
     */
    private static function wc_id_by_slug(string $slug): ?int {
        $post = get_page_by_path($slug, OBJECT, 'product');
        return $post ? (int) $post->ID : null;
    }

    /**
     * Dado o ID do produto WooCommerce (o que o front conhece), resolve o ID da
     * tabela custom de mesmo slug. Falha com o próprio id se não achar.
     */
    public static function resolve_legacy_id_by_wc_id(int $wc_id): int {
        $post = $wc_id ? get_post($wc_id) : null;
        if ($post && $post->post_type === 'product' && $post->post_name) {
            global $wpdb;
            $products = self::table('products');
            $legacy = $wpdb->get_var($wpdb->prepare(
                "SELECT id FROM {$products} WHERE slug = %s LIMIT 1",
                $post->post_name
            ));
            if ($legacy) {
                return (int) $legacy;
            }
        }
        return $wc_id;
    }

    private static function format_number($value): float {
        return (float) ($value ?? 0);
    }

    /**
     * Converte lista de tamanhos em faixa legível: ['PP (36)','P (38)','M (40)'] => 'PP ao M'.
     * Ordena respeitando o número entre parênteses quando existir (PP<->GG real).
     */
    private static function format_size_range(array $sizes): string {
        $sizes = array_values(array_unique($sizes));
        if (!$sizes) {
            return 'M';
        }

        $sort_mapper = [];
        foreach ($sizes as $s) {
            if (preg_match('/\((\d+)\)/', (string) $s, $m)) {
                $sort_mapper[(string) $s] = (int) $m[1];
            } elseif (preg_match('/^\d+$/', (string) $s)) {
                $sort_mapper[(string) $s] = (int) $s;
            } else {
                $sort_mapper[(string) $s] = PHP_INT_MAX / 2;
            }
        }
        if (count(array_filter($sort_mapper, fn($v) => $v !== PHP_INT_MAX / 2)) === count($sort_mapper)) {
            asort($sort_mapper, SORT_NUMERIC);
            $sizes = array_keys($sort_mapper);
        } else {
            sort($sizes, SORT_STRING);
        }

        if (count($sizes) === 1) {
            return (string) $sizes[0];
        }
        $all_numeric = true;
        foreach ($sizes as $s) {
            if (!preg_match('/^\d+$/', (string) $s)) {
                $all_numeric = false;
                break;
            }
        }
        if ($all_numeric) {
            return $sizes[0] . ' ao ' . end($sizes);
        }
        $first = (string) reset($sizes);
        $last = (string) end($sizes);
        $first_label = preg_replace('/^([A-Z]+).*$/', '$1', $first) ?: $first;
        $last_label = preg_replace('/^([A-Z]+).*$/', '$1', $last) ?: $last;
        if ($first_label === $last_label) {
            return $first;
        }
        return $first_label . ' ao ' . $last_label;
    }

    public static function get_products(array $args = []): array {
        global $wpdb;

        $products = self::table('products');
        $categories = self::table('categories');
        $variations = self::table('product_variations');
        $colors = self::table('product_colors');

        $page = max(1, (int) ($args['page'] ?? 1));
        $limit = max(1, (int) ($args['limit'] ?? 12));
        $offset = ($page - 1) * $limit;
        $category = sanitize_text_field($args['category'] ?? '');
        $search = sanitize_text_field($args['search'] ?? '');
        $min_price = isset($args['min_price']) && $args['min_price'] !== null ? (float) $args['min_price'] : null;
        $max_price = isset($args['max_price']) && $args['max_price'] !== null ? (float) $args['max_price'] : null;
        $condition = sanitize_text_field($args['condition'] ?? '');
        $orderby = sanitize_text_field($args['orderby'] ?? 'date');
        $order = strtoupper((string) ($args['order'] ?? 'DESC')) === 'ASC' ? 'ASC' : 'DESC';

        $where = ['p.is_active = 1'];

        if (!empty($category)) {
            $slug = sanitize_title($category);
            $where[] = $wpdb->prepare('p.category_id = (SELECT c.id FROM ' . $categories . ' c WHERE c.slug = %s LIMIT 1)', $slug);
        }
        if (!empty($search)) {
            $like = '%' . $wpdb->esc_like($search) . '%';
            $where[] = $wpdb->prepare('(p.name LIKE %s OR p.fabric LIKE %s OR p.brand LIKE %s)', $like, $like, $like);
        }
        if ($min_price !== null) {
            $where[] = $wpdb->prepare('p.price >= %f', $min_price);
        }
        if ($max_price !== null) {
            $where[] = $wpdb->prepare('p.price <= %f', $max_price);
        }
        if (!empty($condition)) {
            $where[] = $wpdb->prepare('p.`condition` = %s', $condition);
        }

        switch ($orderby) {
            case 'price':
            case 'price-asc':
                $order_sql = 'ORDER BY p.price ASC';
                break;
            case 'price-desc':
                $order_sql = 'ORDER BY p.price DESC';
                break;
            case 'popularity':
            case 'featured':
                $order_sql = 'ORDER BY p.is_featured DESC, p.id DESC';
                break;
            case 'rating':
                $order_sql = 'ORDER BY p.id DESC';
                break;
            default:
                $order_sql = 'ORDER BY p.id ' . $order;
                break;
        }

        $where_sql = implode(' AND ', $where);

        $total = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$products} p WHERE {$where_sql}");

        $rows = $wpdb->get_results(
            "SELECT p.*, c.name AS category_name, c.slug AS category_slug
             FROM {$products} p
             LEFT JOIN {$categories} c ON c.id = p.category_id
             WHERE {$where_sql}
             {$order_sql}
             LIMIT {$offset}, {$limit}"
        , ARRAY_A);

        $items = [];
        foreach ((array) $rows as $row) {
            $items[] = self::format_product($row);
        }

        return [
            'products' => $items,
            'total' => $total,
            'pages' => max(1, (int) ceil($total / $limit)),
            'page' => $page,
        ];
    }

    public static function get_product(int $custom_id): ?array {
        global $wpdb;
        $products = self::table('products');
        $categories = self::table('categories');
        $variations = self::table('product_variations');
        $colors = self::table('product_colors');
        $measurements = self::table('product_measurements');

        $row = $wpdb->get_row($wpdb->prepare(
            "SELECT p.*, c.name AS category_name, c.slug AS category_slug
             FROM {$products} p
             LEFT JOIN {$categories} c ON c.id = p.category_id
             WHERE p.id = %d AND p.is_active = 1
             LIMIT 1", $custom_id), ARRAY_A);

        if (!$row) {
            return null;
        }

        $data = self::format_product($row, true);

        $var_rows = $wpdb->get_results($wpdb->prepare(
            "SELECT v.id, v.sku, v.size, v.stock_quantity, v.price_modifier, v.is_active,
                    col.name AS color_name, col.hex_code
             FROM {$variations} v
             LEFT JOIN {$colors} col ON col.id = v.color_id
             WHERE v.product_id = %d AND v.is_active = 1
             ORDER BY v.size ASC", $custom_id), ARRAY_A);

        $var_data = [];
        foreach ((array) $var_rows as $v) {
            $var_data[] = [
                'id' => (int) $v['id'],
                'sku' => $v['sku'] ?? '',
                'size' => $v['size'] ?? '',
                'color' => $v['color_name'] ?? null,
                'color_hex' => $v['hex_code'] ?? null,
                'price_modifier' => self::format_number($v['price_modifier'] ?? 0),
                'stock_quantity' => (int) ($v['stock_quantity'] ?? 0),
                'in_stock' => ((int) ($v['stock_quantity'] ?? 0)) > 0,
            ];
        }

        $meas = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$measurements} WHERE product_id = %d LIMIT 1", $custom_id), ARRAY_A);

        $data['variations'] = $var_data;
        $data['measurements'] = $meas ? array_diff_key($meas, ['id' => 1, 'product_id' => 1, 'created_at' => 1]) : [];
        $data['sizes'] = array_values(array_unique(array_column($var_data, 'size')));

        return $data;
    }

    public static function get_taxonomies(): array {
        global $wpdb;
        $categories = self::table('categories');
        $products = self::table('products');

        $cats = $wpdb->get_results(
            "SELECT c.id, c.name, c.slug, c.description,
                    (SELECT COUNT(*) FROM {$products} p WHERE p.category_id = c.id AND p.is_active = 1) AS cnt
             FROM {$categories} c
             ORDER BY c.name ASC", ARRAY_A);

        $conditions = $wpdb->get_col("SELECT DISTINCT `condition` FROM {$products} WHERE `condition` IS NOT NULL AND `condition` <> '' AND is_active = 1 ORDER BY `condition` ASC");

        $formatted = [];
        foreach ((array) $cats as $c) {
            $formatted[] = [
                'id' => (int) $c['id'],
                'name' => $c['name'],
                'slug' => $c['slug'],
                'count' => (int) $c['cnt'],
            ];
        }

        return [
            'categories' => $formatted,
            'conditions' => $conditions ?: ['Estado de Novo', 'Sem marcas de uso', 'Vintage Exclusivo', 'Peça Única', 'Com leve desgaste'],
            'measurements_labels' => [
                'bust' => 'Busto', 'waist' => 'Cintura', 'hips' => 'Quadril',
                'length' => 'Comprimento', 'shoulder' => 'Ombro',
                'heel_height' => 'Altura do salto', 'insole_length' => 'Tamanho da palmilha',
            ],
        ];
    }

    public static function format_product(array $row, bool $full_details = false): array {
        global $wpdb;

        $id = (int) $row['id'];
        $price = self::format_number($row['price']);
        $regular = self::format_number($row['regular_price'] ?? 0);
        $on_sale = $regular > 0 && $regular > $price;

        // Soma o estoque das variações ativas (grade completa = estoque real do pai)
        $variations = self::table('product_variations');
        $stock_qty = (int) $wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(stock_quantity), 0) FROM {$variations} WHERE product_id = %d AND is_active = 1", $id));
        $in_stock = $stock_qty > 0;

        // Faixa de tamanhos reais da grade (para o card mostrar "PP ao GG" em vez de "M")
        $size_range = '';
        if ($in_stock) {
            $sizes = $wpdb->get_col($wpdb->prepare(
                "SELECT DISTINCT v.size FROM {$variations} v WHERE v.product_id = %d AND v.is_active = 1 AND v.stock_quantity > 0 ORDER BY v.size ASC",
                $id
            ));
            $size_range = self::format_size_range($sizes);
        }

        $wc_id = self::wc_id_by_slug($row['slug'] ?? '');

        $data = [
            'id' => $wc_id ?? $id,
            'legacy_id' => $id,
            'name' => $row['name'] ?? '',
            'slug' => $row['slug'] ?? '',
            'price' => $price,
            'regular_price' => $regular > 0 ? $regular : null,
            'sale_price' => $on_sale ? $price : null,
            'on_sale' => $on_sale,
            'image' => $row['main_image'] ?? '',
            'categories' => isset($row['category_name']) && $row['category_name'] ? [$row['category_name']] : [],
            'rating' => 0.0,
            'rating_count' => 0,
            'in_stock' => $in_stock,
            'stock_quantity' => $stock_qty,
            'condition' => $row['condition'] ?? 'Estado de Novo',
            'size' => $size_range ?: 'M',
            'brand' => $row['brand'] ?? 'Todday Modas Seleção',
            'fabric' => $row['fabric'] ?? null,
        ];

        if ($full_details) {
            $data['description'] = $row['description'] ?? '';
            $data['short_description'] = '';
            $data['care_instructions'] = $row['care_instructions'] ?? null;
            $data['gallery'] = [];
            $data['tags'] = [];
            $data['category_id'] = isset($row['category_id']) ? (int) $row['category_id'] : null;
        }

        return $data;
    }
}