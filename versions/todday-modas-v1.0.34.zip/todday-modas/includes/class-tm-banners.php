<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

class TM_Banners {
    public static function init() {
        add_action( 'init', array( __CLASS__, 'registra_cpt' ) );
        add_action( 'rest_api_init', array( __CLASS__, 'registra_rest' ) );
        add_action( 'wp_ajax_tm_save_banner', array( __CLASS__, 'ajax_save_banner' ) );
        add_action( 'wp_ajax_tm_delete_banner', array( __CLASS__, 'ajax_delete_banner' ) );
    }

    public static function registra_cpt() {
        $labels = array(
            'name'               => __( 'Banners Todday', 'todday-modas' ),
            'singular_name'      => __( 'Banner', 'todday-modas' ),
            'add_new'            => __( 'Adicionar Banner', 'todday-modas' ),
            'add_new_item'       => __( 'Novo Banner Promocional', 'todday-modas' ),
            'edit_item'          => __( 'Editar Banner', 'todday-modas' ),
            'all_items'          => __( 'Todos os Banners', 'todday-modas' ),
        );

        $args = array(
            'labels'              => $labels,
            'public'              => false,
            'show_ui'             => true,
            'show_in_menu'        => 'todday-modas',
            'supports'            => array( 'title', 'thumbnail' ),
            'show_in_rest'        => true,
        );

        register_post_type( 'tm_banner', $args );
    }

    public static function registra_rest() {
        register_rest_route( 'tm/v1', '/banners', array(
            'methods'             => 'GET',
            'callback'            => array( __CLASS__, 'get_banners_rest' ),
            'permission_callback' => '__return_true',
        ) );
    }

    public static function get_banners_rest() {
        $posts = get_posts( array(
            'post_type'      => 'tm_banner',
            'posts_per_page' => 10,
            'post_status'    => 'publish',
        ) );

        $data = array();
        foreach ( $posts as $p ) {
            $data[] = array(
                'id'    => $p->ID,
                'title' => get_the_title( $p ),
                'image' => get_the_post_thumbnail_url( $p, 'full' ),
            );
        }
        return rest_ensure_response( $data );
    }

    public static function ajax_save_banner() {
        check_ajax_referer( 'tm_admin_nonce', 'nonce' );

        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( array( 'message' => __( 'Permissão negada.', 'todday-modas' ) ), 403 );
        }

        $title = isset( $_POST['title'] ) ? sanitize_text_field( wp_unslash( $_POST['title'] ) ) : '';
        $link  = isset( $_POST['link'] ) ? esc_url_raw( wp_unslash( $_POST['link'] ) ) : '';
        $image = isset( $_POST['image'] ) ? trim( sanitize_text_field( wp_unslash( $_POST['image'] ) ) ) : '';
        $id    = isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0;

        if ( '' === $title ) {
            wp_send_json_error( array( 'message' => __( 'Informe um título para o banner.', 'todday-modas' ) ), 400 );
        }

        $postarr = array(
            'post_type'   => 'tm_banner',
            'post_status' => 'publish',
            'post_title'  => $title,
        );
        if ( $id ) {
            $postarr['ID'] = $id;
        }
        $saved = wp_insert_post( $postarr, true );

        if ( is_wp_error( $saved ) ) {
            wp_send_json_error( array( 'message' => $saved->get_error_message() ), 500 );
        }

        if ( '' !== $link ) {
            update_post_meta( $saved, '_tm_banner_link', $link );
        } else {
            delete_post_meta( $saved, '_tm_banner_link' );
        }

        if ( is_numeric( $image ) && (int) $image > 0 ) {
            set_post_thumbnail( $saved, (int) $image );
        } elseif ( '' !== $image ) {
            update_post_meta( $saved, '_tm_banner_image', esc_url_raw( $image ) );
        }

        wp_send_json_success( array(
            'id'    => (int) $saved,
            'title' => $title,
        ) );
    }

    public static function ajax_delete_banner() {
        check_ajax_referer( 'tm_admin_nonce', 'nonce' );

        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( array( 'message' => __( 'Permissão negada.', 'todday-modas' ) ), 403 );
        }

        $id = isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0;
        if ( ! $id || 'tm_banner' !== get_post_type( $id ) ) {
            wp_send_json_error( array( 'message' => __( 'Banner não encontrado.', 'todday-modas' ) ), 404 );
        }

        $deleted = wp_delete_post( $id, true );
        if ( ! $deleted ) {
            wp_send_json_error( array( 'message' => __( 'Falha ao remover o banner.', 'todday-modas' ) ), 500 );
        }

        wp_send_json_success( array( 'id' => $id ) );
    }
}
