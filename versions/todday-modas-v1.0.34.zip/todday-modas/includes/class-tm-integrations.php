<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

class TM_Integrations {
    public static function init() {
        // Integracoes de pagamento sao tratadas pelos gateways do plugin oficial
        // do Mercado Pago (woo-mercado-pago-*), configurados em WooCommerce > Pagamentos.
    }
}
