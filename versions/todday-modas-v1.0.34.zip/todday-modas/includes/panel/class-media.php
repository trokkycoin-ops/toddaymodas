<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

class TM_Panel_Media {
    public static function init() {
        add_action( 'rest_api_init', array( __CLASS__, 'register_routes' ) );
    }

    public static function register_routes() {
        register_rest_route( 'tm/v1', '/media/upload', array(
            'methods'             => 'POST',
            'callback'            => array( __CLASS__, 'handle_upload' ),
            'permission_callback' => function() {
                return current_user_can( 'manage_options' ) || current_user_can( 'tm_panel' );
            },
        ) );
    }

    /**
     * Upload de imagem com proteção CSRF (nonce), whitelist de tipo (jpg/jpeg/png/webp),
     * limite de tamanho e insert real na biblioteca de mídia.
     */
    public static function handle_upload( WP_REST_Request $request ) {
        // 1) Nonce CSRF. Header X-WP-Nonce (padrão REST do WP) ou nonce tm_admin_nonce no body.
        $header_nonce = isset( $_SERVER['HTTP_X_WP_NONCE'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_X_WP_NONCE'] ) ) : '';
        $body_nonce   = $request->get_param( 'nonce' );
        $nonce_ok     = ( ! empty( $header_nonce ) && wp_verify_nonce( $header_nonce, 'wp_rest' ) )
            || ( is_string( $body_nonce ) && ! empty( $body_nonce ) && wp_verify_nonce( $body_nonce, 'tm_admin_nonce' ) );

        if ( ! $nonce_ok ) {
            return new WP_Error(
                'tm_forbidden',
                __( 'Sessão expirada ou não autorizada. Recarregue o painel e tente novamente.', 'todday-modas' ),
                array( 'status' => 403 )
            );
        }

        // 2) Arquivo presente e sem erro de envio.
        if ( empty( $_FILES['file'] ) || ! is_array( $_FILES['file'] ) ) {
            return new WP_Error( 'tm_no_file', __( 'Nenhum arquivo foi enviado.', 'todday-modas' ), array( 'status' => 400 ) );
        }
        $file = $_FILES['file'];
        if ( isset( $file['error'] ) && (int) $file['error'] !== UPLOAD_ERR_OK ) {
            return new WP_Error( 'tm_upload_error', __( 'Falha no envio do arquivo.', 'todday-modas' ), array( 'status' => 400 ) );
        }

        // 3) Whitelist de extensão (auditoria: permitir apenas jpg, jpeg, png, webp).
        $ext = strtolower( pathinfo( $file['name'], PATHINFO_EXTENSION ) );
        if ( ! in_array( $ext, array( 'jpg', 'jpeg', 'png', 'webp' ), true ) ) {
            return new WP_Error(
                'tm_bad_type',
                __( 'Tipo de arquivo não permitido. Envie apenas JPG, PNG ou WEBP.', 'todday-modas' ),
                array( 'status' => 400 )
            );
        }

        // 4) Limite de tamanho (3 MB).
        $max_size = 3 * 1024 * 1024;
        if ( (int) $file['size'] > $max_size ) {
            return new WP_Error(
                'tm_file_too_big',
                __( 'Imagem muito grande. O limite é de 3 MB.', 'todday-modas' ),
                array( 'status' => 413 )
            );
        }

        // 5) Mover para uploads com whitelist de MIME.
        require_once ABSPATH . 'wp-admin/includes/file.php';
        $uploaded = wp_handle_upload( $file, array(
            'test_form' => false,
            'mimes'     => array(
                'jpg|jpeg' => 'image/jpeg',
                'png'      => 'image/png',
                'webp'     => 'image/webp',
            ),
        ) );

        if ( isset( $uploaded['error'] ) || empty( $uploaded['file'] ) ) {
            return new WP_Error(
                'tm_upload_fail',
                isset( $uploaded['error'] ) ? sanitize_text_field( $uploaded['error'] ) : __( 'Falha ao salvar o arquivo.', 'todday-modas' ),
                array( 'status' => 500 )
            );
        }

        // 6) Registrar na biblioteca de mídia (com metadata).
        require_once ABSPATH . 'wp-admin/includes/image.php';
        $attach_id = wp_insert_attachment( array(
            'post_mime_type' => $uploaded['type'],
            'post_title'     => sanitize_file_name( pathinfo( $file['name'], PATHINFO_FILENAME ) ),
            'post_status'    => 'inherit',
            'guid'           => $uploaded['url'],
        ), $uploaded['file'] );

        if ( ! is_wp_error( $attach_id ) && $attach_id ) {
            $meta = wp_generate_attachment_metadata( $attach_id, $uploaded['file'] );
            wp_update_attachment_metadata( $attach_id, $meta );
        }

        return rest_ensure_response( array(
            'success' => true,
            'id'      => $attach_id ? (int) $attach_id : 0,
            'url'     => $uploaded['url'],
        ) );
    }
}