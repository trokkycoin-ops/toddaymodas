=== Todday Modas ===
Contributors: Tselak Solutions
Tags: woocommerce, brecho, moda circular, elementor, mercado pago, cupons
Requires at least: 6.4
Tested up to: 6.7
Requires PHP: 8.1
Stable tag: 1.0.34
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Paineis administrativos, identidade visual e integracoes da loja Todday Modas (brecho de moda circular). Estende o WooCommerce e integra com Elementor e Mercado Pago.

== Description ==

Plugin oficial da boutique e brecho online Todday Modas.
Fornece vitrines editoriais, secoes especializadas, integracao com Mercado Pago, widgets Elementor, banner LGPD de consentimento e painel administrativo completo.

Shortcodes disponiveis:
* [tm_home] - Shortcode MASTER que renderiza a pagina inicial completa.
* [tm_hero] - Secao hero principal com slider editorial.
* [tm_categorias] - Grade visual de departamentos e categorias.
* [tm_banners] - Banners promocionais estrategicos.
* [tm_cupons] - Grid de cupons promocionais ativos.
* [tm_kids] - Vitrine especializada para moda infantil.
* [tm_contato] - Formulario seguro de contato com validacao nonce.

== Installation ==

1. Envie a pasta 'todday-modas' para o diretorio '/wp-content/plugins/' ou envie o arquivo 'todday-modas.zip' pelo painel do WordPress em Plugins > Adicionar Novo > Enviar Plugin.
2. Ative o plugin atraves do menu 'Plugins' no WordPress.
3. Certifique-se de que o WooCommerce esteja instalado e ativo.
4. Utilize o shortcode [tm_home] na sua pagina inicial.

== Changelog ==

= 1.0.34 =
* Corrigido o quebra de layout da home: o build AI Studio enfileirava somente o CSS do storefront React (tm-front.css) e suprimia o CSS editorial das secoes server-side (tm-hero, tm-kids, tm-categorias, tm-banners). Restaurado o enqueue de tm-variables.css + tm-public.css + tm-public.js (com os dados TMDados), mantendo o storefront React.

= 1.0.33 =
* Seed de estrutura (TM_Setup): cria automaticamente a pagina Inicio, as instituicionais (Sobre, Termos, Privacidade, FAQ, Trocas e Devolucoes, Contato), o menu principal e a configuracao de front page estatica — o plugin passa a ser a fonte de verdade da loja e reconstroi a estrutura mesmo com banco recriado.
* Adicionado o arquivo includes/class-tm-setup.php e sua inicializacao no bootstrap.

= 1.0.32 =
* Corrigido upload de midia REST /tm/v1/media/upload: implementado com nonce CSRF, whitelist de tipo (jpg/jpeg/png/webp), limite de 3MB, persistencia na biblioteca com metadata e respostas de erro reais (antes retornava sucesso sem salvar).
* Removido gateway Mercado Pago customizado morto (nao era carregado; o site usa o plugin oficial woo-mercado-pago-*).
* Painel de Banners reativado: view funcional com formulario e lista, handlers AJAX tm_save_banner/tm_delete_banner com nonce e capacidade, enqueue e localizacao dos textos do admin (i18n).

= 1.0.31 =
* Header legado do tema Astra ocultado (desktop e mobile): o site passa a exibir somente o header do plugin (vitrine/storefront).

= 1.0.30 =
* Responsividade do header corrigida em celulares estreitos (<414px) e na faixa lg (1024-1279px): sem overflow horizontal; botoes acessorios ocultos quando necessario.
* Botao de scroll-to-top (Astra #ast-scroll-top) reestilizado com identidade Todday: fundo grafite #1A1918, borda terracota, formato pill 44px e posicionamento correto.

= 1.0.29 =
* Corrigido botoes do storefront herdando a cor primaria do tema Astra (azul #046bd2) em vez das cores do design (terracota, grafite, off-white, verde-oliva). Override de utilidades Tailwind v4 re-emitidas sem cascade layer e escopadas em #tm-storefront-root.

= 1.0.28 =
* Adicionado shortcode master [tm_home] com controle individual de secoes via show_*.
* Correcao da criacao de tabelas em init com dbDelta.
* Compatibilidade declarada com HPOS (High-Performance Order Storage).
* Requisicao minima atualizada para WordPress 6.4 e PHP 8.1.
