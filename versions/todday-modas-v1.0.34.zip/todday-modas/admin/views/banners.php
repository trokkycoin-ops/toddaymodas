<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
if ( ! current_user_can( 'manage_options' ) ) {
    wp_die( esc_html__( 'Acesso nao autorizado.', 'todday-modas' ) );
}

$existing = get_posts( array(
    'post_type'      => 'tm_banner',
    'numberposts'    => 20,
    'post_status'    => array( 'publish', 'draft' ),
) );
?>
<div class="wrap tm-admin-wrap">
    <h1><?php esc_html_e( 'Banners Promocionais', 'todday-modas' ); ?></h1>

    <div id="tm-banner-notice" class="notice" style="display:none"></div>

    <form id="tm-form-banner" class="tm-admin-card" method="post">
        <h2><?php esc_html_e( 'Novo Banner', 'todday-modas' ); ?></h2>
        <p>
            <label><?php esc_html_e( 'Titulo', 'todday-modas' ); ?></label><br>
            <input type="text" name="title" required class="regular-text" />
        </p>
        <p>
            <label><?php esc_html_e( 'Link (URL)', 'todday-modas' ); ?></label><br>
            <input type="url" name="link" class="regular-text" placeholder="https://" />
        </p>
        <p>
            <label><?php esc_html_e( 'Imagem (ID do anexo ou URL)', 'todday-modas' ); ?></label><br>
            <input type="text" name="image" class="regular-text" />
        </p>
        <p>
            <button type="submit" class="button button-primary"><?php esc_html_e( 'Salvar Banner', 'todday-modas' ); ?></button>
        </p>
    </form>

    <h2><?php esc_html_e( 'Banners Existentes', 'todday-modas' ); ?></h2>
    <?php if ( empty( $existing ) ) : ?>
        <p><?php esc_html_e( 'Nenhum banner cadastrado ainda.', 'todday-modas' ); ?></p>
    <?php else : ?>
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th><?php esc_html_e( 'Titulo', 'todday-modas' ); ?></th>
                    <th><?php esc_html_e( 'Status', 'todday-modas' ); ?></th>
                    <th><?php esc_html_e( 'Acoes', 'todday-modas' ); ?></th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ( $existing as $banner ) : ?>
                <tr>
                    <td><?php echo esc_html( get_the_title( $banner ) ); ?></td>
                    <td><?php echo esc_html( ( get_post_status_object( get_post_status( $banner ) ) ? get_post_status_object( get_post_status( $banner ) )->label : get_post_status( $banner ) ) ); ?></td>
                    <td>
                        <button type="button" class="button tm-btn-delete-banner" data-id="<?php echo esc_attr( $banner->ID ); ?>"><?php esc_html_e( 'Remover', 'todday-modas' ); ?></button>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>