/* global tmAdminData, jQuery */
jQuery(document).ready(function($) {
    'use strict';

    var i18n = (window.tmAdminData && window.tmAdminData.i18n) || {};
    var $notice = $('#tm-banner-notice');

    function showNotice(message, type) {
        if (!$notice.length) {
            return;
        }
        $notice
            .removeClass('notice-success notice-error')
            .addClass(type === 'error' ? 'notice-error' : 'notice-success')
            .text(message)
            .show();
        setTimeout(function() {
            $notice.fadeOut(400);
        }, 3500);
    }

    // Salvar Banner via AJAX
    $('#tm-form-banner').on('submit', function(e) {
        e.preventDefault();
        var formData = $(this).serializeArray();
        formData.push({ name: 'action', value: 'tm_save_banner' });
        formData.push({ name: 'nonce', value: window.tmAdminData.nonce });

        $.post(window.tmAdminData.ajaxUrl, formData)
            .done(function(res) {
                if (res && res.success) {
                    showNotice(i18n.saveSuccess || 'Banner salvo com sucesso!');
                    setTimeout(function() {
                        window.location.reload();
                    }, 700);
                } else {
                    showNotice(
                        (res && res.data && res.data.message) || (i18n.saveError || 'Falha ao salvar o banner.'),
                        'error'
                    );
                }
            })
            .fail(function(xhr) {
                var message = (xhr && xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message) ||
                    (i18n.networkError || 'Falha de conexao. Tente novamente.');
                showNotice(message, 'error');
            });
    });

    // Deletar Banner via AJAX
    $('.tm-btn-delete-banner').on('click', function(e) {
        e.preventDefault();
        if (!window.confirm(i18n.deleteConfirm || 'Deseja realmente remover este banner?')) {
            return;
        }
        var bannerId = $(this).data('id');

        $.post(window.tmAdminData.ajaxUrl, {
            action: 'tm_delete_banner',
            nonce: window.tmAdminData.nonce,
            id: bannerId
        })
            .done(function(res) {
                if (res && res.success) {
                    showNotice(i18n.deleteSuccess || 'Banner removido.');
                    setTimeout(function() {
                        window.location.reload();
                    }, 700);
                } else {
                    showNotice(
                        (res && res.data && res.data.message) || (i18n.deleteError || 'Falha ao remover o banner.'),
                        'error'
                    );
                }
            })
            .fail(function() {
                showNotice(i18n.networkError || 'Falha de conexao. Tente novamente.', 'error');
            });
    });
});