=== Todday Modas ===
Contributors: tselaksolutions
Tags: woocommerce, elementor, mercado-pago, moda, loja
Requires at least: 6.4
Tested up to: 6.9
Requires PHP: 8.1
Requires Plugins: woocommerce
Stable tag: 1.0.1
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Painéis administrativos, identidade visual e integrações da loja Todday Modas.

== Descrição ==

Plugin oficial da loja Todday Modas. Estende o WooCommerce e integra com Elementor e Mercado Pago.

**Painéis administrativos:**
* Dashboard (vendas do dia, pedidos pendentes, estoque baixo)
* Configurações da Marca (logo, paleta de cores, tipografia)
* Gestão de Banners (upload, link, ordem, agendamento)
* Cupons e Promoções (interface simplificada sobre WC_Coupon)
* Relatórios (vendas 30 dias, top produtos)
* Configurações de Frete (frete grátis + atalhos das zonas)
* Integrações (Mercado Pago com credenciais criptografadas, WhatsApp, e-mail marketing)
* Logs & Segurança (eventos, logins falhos, alterações críticas)

**Widgets Elementor:**
* TM Produto em Destaque
* TM Banner com CTA
* TM Grade de Categorias

**Extras:**
* Paleta de cores como variáveis CSS (`--tm-*`) em todo o front
* Botão flutuante de WhatsApp
* Aviso de frete grátis acima de valor configurável
* Selos de confiança no checkout
* E-mails transacionais com as cores da marca
* Template 404 personalizado
* Compatível com HPOS

== Instalação ==

1. Envie a pasta `todday-modas` para `/wp-content/plugins/`
2. Ative o plugin no menu "Plugins"
3. Acesse o menu "Todday Modas" no wp-admin

== Changelog ==

= 1.0.1 =
* Rodapé profissional da marca (colunas de links, formas de pagamento, selos de confiança).
* Shortcode [tm_categorias] e [tm_contato] (formulário com nonce, honeypot e rate-limit).
* Widget Elementor TM Cupons + shortcode [tm_cupons] com botão de copiar.
* Correções de catálogo (peso/dimensões/SKU/marca aplicados na loja).

= 1.0.0 =
* Versão inicial.
