/* Público — Todday Modas. Leve, sem dependências. */
(function () {
	'use strict';

	document.addEventListener('DOMContentLoaded', function () {
		// Lazy load defensivo: garante loading="lazy" em imgs de conteúdo sem o atributo.
		var imgs = document.querySelectorAll('.woocommerce img:not([loading])');
		imgs.forEach(function (img) {
			img.setAttribute('loading', 'lazy');
			img.setAttribute('decoding', 'async');
		});

		// Botões "copiar cupom" (seção TM Cupons).
		document.querySelectorAll('.tm-cupom-copiar').forEach(function (btn) {
			btn.addEventListener('click', function () {
				var codigo = btn.getAttribute('data-codigo') || '';
				var label = btn.querySelector('.tm-cupom-copiar-label');
				var original = label ? label.textContent : '';

				function sucesso() {
					btn.classList.add('copiado');
					if (label) { label.textContent = 'Copiado!'; }
					setTimeout(function () {
						btn.classList.remove('copiado');
						if (label) { label.textContent = original; }
					}, 2000);
				}

				if (navigator.clipboard && navigator.clipboard.writeText) {
					navigator.clipboard.writeText(codigo).then(sucesso).catch(function () {
						fallback(codigo, sucesso);
					});
				} else {
					fallback(codigo, sucesso);
				}
			});
		});

		function fallback(texto, cb) {
			var ta = document.createElement('textarea');
			ta.value = texto;
			ta.style.position = 'fixed';
			ta.style.opacity = '0';
			document.body.appendChild(ta);
			ta.select();
			try {
				document.execCommand('copy');
				cb();
			} catch (e) { /* silencioso */ }
			document.body.removeChild(ta);
		}
	});
})();
