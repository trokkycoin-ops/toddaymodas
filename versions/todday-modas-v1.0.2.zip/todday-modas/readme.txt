=== Todday Modas ===
Contributors: tselaksolutions
Tags: woocommerce, elementor, mercado-pago, moda, loja
Requires at least: 6.4
Tested up to: 6.9
Requires PHP: 8.1
Requires Plugins: woocommerce
Stable tag: 1.0.2
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

PainÃ©is administrativos, identidade visual e integraÃ§Ãµes da loja Todday Modas.

== DescriÃ§Ã£o ==

Plugin oficial da loja Todday Modas. Estende o WooCommerce e integra com Elementor e Mercado Pago.

**PainÃ©is administrativos:**
* Dashboard (vendas do dia, pedidos pendentes, estoque baixo)
* ConfiguraÃ§Ãµes da Marca (logo, paleta de cores, tipografia)
* GestÃ£o de Banners (upload, link, ordem, agendamento)
* Cupons e PromoÃ§Ãµes (interface simplificada sobre WC_Coupon)
* RelatÃ³rios (vendas 30 dias, top produtos)
* ConfiguraÃ§Ãµes de Frete (frete grÃ¡tis + atalhos das zonas)
* IntegraÃ§Ãµes (Mercado Pago com credenciais criptografadas, WhatsApp, e-mail marketing)
* Logs & SeguranÃ§a (eventos, logins falhos, alteraÃ§Ãµes crÃ­ticas)

**Widgets Elementor:**
* TM Produto em Destaque
* TM Banner com CTA
* TM Grade de Categorias

**Extras:**
* Paleta de cores como variÃ¡veis CSS (`--tm-*`) em todo o front
* BotÃ£o flutuante de WhatsApp
* Aviso de frete grÃ¡tis acima de valor configurÃ¡vel
* Selos de confianÃ§a no checkout
* E-mails transacionais com as cores da marca
* Template 404 personalizado
* CompatÃ­vel com HPOS

== InstalaÃ§Ã£o ==

1. Envie a pasta `todday-modas` para `/wp-content/plugins/`
2. Ative o plugin no menu "Plugins"
3. Acesse o menu "Todday Modas" no wp-admin

== Changelog ==

= 1.0.1 =
* RodapÃ© profissional da marca (colunas de links, formas de pagamento, selos de confianÃ§a).
* Shortcode [tm_categorias] e [tm_contato] (formulÃ¡rio com nonce, honeypot e rate-limit).
* Widget Elementor TM Cupons + shortcode [tm_cupons] com botÃ£o de copiar.
* CorreÃ§Ãµes de catÃ¡logo (peso/dimensÃµes/SKU/marca aplicados na loja).

= 1.0.0 =
* VersÃ£o inicial.
