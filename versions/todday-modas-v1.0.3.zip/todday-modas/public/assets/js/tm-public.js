/* Público — Todday Modas v1.0.3. Leve, sem dependências. */
(function () {
	'use strict';

	var prm = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

	/* ============ PWA: registra service worker ============ */
	if ('serviceWorker' in navigator) {
		window.addEventListener('load', function () {
			navigator.serviceWorker.register('/tm-sw.js', { scope: '/' }).catch(function () { /* silencioso */ });
		});
	}

	/* ============ Header: efeito "vidro" ao rolar ============ */
	var lastY = 0;
	function onScroll() {
		var y = window.scrollY || 0;
		document.body.classList.toggle('tm-scrolled', y > 12);
		// esconde/mostra header ao rolar pra cima/baixo (como app nativo)
		var header = document.querySelector('.site-header, header.ast-primary-header-bar, .ast-desktop');
		if (header) {
			if (y > 180 && y > lastY + 6) { document.body.classList.add('tm-header-hidden'); }
			else if (y < lastY - 6) { document.body.classList.remove('tm-header-hidden'); }
		}
		lastY = y;
	}
	window.addEventListener('scroll', onScroll, { passive: true });

	document.addEventListener('DOMContentLoaded', function () {

		/* ============ Animações de entrada (IntersectionObserver, stagger) ============ */
		var alvos = document.querySelectorAll(
			'.tm-hero, .tm-secao, .tm-fullbleed, .tm-cat-card, .tm-cupom, ' +
			'.woocommerce ul.products li.product, .tm-card-produto-destaque, .tm-banner-cta, ' +
			'.tm-footer, .tm-contato-canal, .tm-faq details, .tm-newsletter, .tm-doc'
		);
		if (prm || !('IntersectionObserver' in window)) {
			alvos.forEach(function (el) { el.classList.add('tm-in'); });
		} else {
			alvos.forEach(function (el, i) {
				el.classList.add('tm-pre');
				el.style.setProperty('--tm-delay', ((i % 6) * 70) + 'ms');
			});
			var io = new IntersectionObserver(function (entries) {
				entries.forEach(function (en) {
					if (en.isIntersecting) {
						en.target.classList.add('tm-in');
						io.unobserve(en.target);
					}
				});
			}, { threshold: 0.08, rootMargin: '0px 0px -6% 0px' });
			alvos.forEach(function (el) { io.observe(el); });
		}

		/* ============ Overlay de busca (app bar) ============ */
		var overlay = document.getElementById('tm-busca-overlay');
		var btnOpen = document.getElementById('tm-busca-open');
		var btnClose = document.getElementById('tm-busca-close');
		var campo = document.getElementById('tm-busca-campo');

		function abrirBusca() {
			if (!overlay) { return; }
			overlay.hidden = false;
			document.body.classList.add('tm-busca-aberta');
			requestAnimationFrame(function () {
				overlay.classList.add('is-open');
				if (campo) { campo.focus(); }
			});
		}
		function fecharBusca() {
			if (!overlay) { return; }
			overlay.classList.remove('is-open');
			document.body.classList.remove('tm-busca-aberta');
			setTimeout(function () { overlay.hidden = true; }, 260);
			if (btnOpen) { btnOpen.focus(); }
		}
		if (btnOpen) { btnOpen.addEventListener('click', abrirBusca); }
		if (btnClose) { btnClose.addEventListener('click', fecharBusca); }
		if (overlay) {
			overlay.addEventListener('click', function (e) { if (e.target === overlay) { fecharBusca(); } });
		}
		document.addEventListener('keydown', function (e) {
			if (e.key === 'Escape' && overlay && !overlay.hidden) { fecharBusca(); }
		});

		/* ============ Lazy load defensivo ============ */
		var imgs = document.querySelectorAll('.woocommerce img:not([loading])');
		imgs.forEach(function (img) {
			img.setAttribute('loading', 'lazy');
			img.setAttribute('decoding', 'async');
		});

		/* ============ Botões "copiar cupom" ============ */
		document.querySelectorAll('.tm-cupom-copiar').forEach(function (btn) {
			btn.addEventListener('click', function () {
				var codigo = btn.getAttribute('data-codigo') || '';
				var label = btn.querySelector('.tm-cupom-copiar-label');
				var original = label ? label.textContent : '';

				function sucesso() {
					btn.classList.add('copiado');
					if (label) { label.textContent = 'Copiado!'; }
					setTimeout(function () {
						btn.classList.remove('copiado');
						if (label) { label.textContent = original; }
					}, 2000);
				}

				if (navigator.clipboard && navigator.clipboard.writeText) {
					navigator.clipboard.writeText(codigo).then(sucesso).catch(function () {
						fallback(codigo, sucesso);
					});
				} else {
					fallback(codigo, sucesso);
				}
			});
		});

		function fallback(texto, cb) {
			var ta = document.createElement('textarea');
			ta.value = texto;
			ta.style.position = 'fixed';
			ta.style.opacity = '0';
			document.body.appendChild(ta);
			ta.select();
			try {
				document.execCommand('copy');
				cb();
			} catch (e) { /* silencioso */ }
			document.body.removeChild(ta);
		}
	});
})();
