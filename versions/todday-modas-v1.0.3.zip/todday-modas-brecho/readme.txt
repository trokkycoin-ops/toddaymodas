=== Todday Modas Brechó ===
Contributors: tselaksolutions
Donate link: https://tselak.com.br
Tags: woocommerce, brecho, vintage, mercadopago, melhorenvio, viacep, elementor, pwa
Requires at least: 6.0
Tested up to: 6.7
Requires PHP: 8.1
Stable tag: 1.0.3
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Loja virtual premium sobre WooCommerce para Todday Modas Brechó. Catálogo customizado, checkout com ViaCEP, Melhor Envio e Mercado Pago, painéis SPA fora do wp-admin, PWA e widgets Elementor.

== Description ==

O plugin **Todday Modas Brechó** transforma uma instalação padrão do WordPress + WooCommerce + Elementor em uma experiência sofisticada de brechó e moda circular.

### Funcionalidades Principais:
* **Catálogo Customizado**: Vitrine moderna com filtros rápidos (categorias, condição da peça brechó, ordenação, busca instantânea).
* **Checkout Brasileiro Integrado**:
  - Consulta automática de endereço via ViaCEP.
  - Cálculo de frete dinâmico via Melhor Envio (SEDEX, PAC, transportadoras) com fallback nativo controlado.
  - Gateway de pagamento Mercado Pago nativo com suporte a PIX instantâneo e Cartão de Crédito.
* **Compatibilidade HPOS**: 100% compatível com WooCommerce High-Performance Order Storage (HPOS).
* **Painel de Gestão SPA (/todday-painel/)**:
  - Painel autônomo fora do wp-admin para Gerentes e Administradores.
  - Gráficos nativos com Chart.js local (sem CDN externo).
  - Emissão de fatura/recibo em PDF server-side embutido.
  - Gestão de pedidos, estoque, clientes e cupons nativos do WooCommerce.
* **Painel do Vendedor (/todday-vendedor/)**: Acompanhamento exclusivo de comissões e pedidos vinculados ao operador.
* **Painel do Cliente (/todday-cliente/)**: Rastreamento de pedidos, histórico e avaliações.
* **PWA Instalável**: Manifest e Service Worker registrados sob HTTPS na loja e nos painéis.
* **Widgets Elementor**: Vitrine Todday, Carrinho Todday, Checkout Todday e Botão Flutuante de WhatsApp.

== Installation ==

1. Faça o upload do arquivo `todday-modas-brecho.zip` em **Plugins > Adicionar Novo > Enviar Plugin** no seu painel WordPress.
2. Clique em **Instalar Agora** e, em seguida, em **Ativar Plugin**.
3. Certifique-se de que o **WooCommerce** esteja ativo.
4. Acesse o menu **Todday Modas > Configurações** para configurar suas credenciais do Mercado Pago e Melhor Envio.
5. O painel SPA estará disponível na URL `https://seusite.com.br/todday-painel/`.

== Frequently Asked Questions ==

= O plugin funciona sem WooCommerce? =
O plugin ativa sem quebrar o site, mas exibirá um aviso no painel informando que o WooCommerce é necessário para as operações comerciais (produtos, pedidos e checkout).

= O painel SPA requer login do WordPress? =
Sim. O painel utiliza autenticação real baseada em cookies de sessão do WordPress e validação rigorosa de permissões (matriz de capacidades) no servidor.

== Changelog ==

= 1.0.3 =
* Bundle React do storefront sincronizado com o app (botão de download do plugin atualizado para o pacote de produção).
* Nome do zip de download corrigido para 218 KB e checksum SHA-256 real.

= 1.0.2 =
* Correção do conflito com o tema: CSS do app sem cascade layers e isolamento do storefront (esconde header/footer do tema Astra na loja).
* Assets do app carregados somente na página da loja.

= 1.0.1 =
* Front da loja substituído pelo app React lilás exportado do AI Studio (bundle em assets/react/).
* Catálogo, frete e checkout ligados às rotas REST reais do plugin (catalog, shipping/quote, checkout/place).
* Aliases de shortcodes legados tm_home, tm_carrinho, tm_checkout e tm_contato.

= 1.0.0 =
* Lançamento inicial de produção.
* Suporte a HPOS, ViaCEP, Melhor Envio e Mercado Pago.
* Painéis SPA de gestão, vendedor e cliente.
* Widgets Elementor e PWA.
